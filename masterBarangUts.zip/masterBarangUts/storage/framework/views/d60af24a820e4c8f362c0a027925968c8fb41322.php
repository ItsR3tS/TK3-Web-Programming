

<?php $__env->startSection('content'); ?>

    
        <div class="container mt-4">
            <h4><?php echo e($pageTitle); ?></h4>
            <hr>
            <a href="<?php echo e(route('barangs.create')); ?>" class="btn btn-primary mb-3">Create Barang</a>
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>Kode</th>
                            <th>Nama Barang</th>
                            <th>Harga</th>
                            <th>Deskripsi</th>
                            <th>Type</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $barangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($barang->kode); ?></td>
                                <td><?php echo e($barang->nama); ?></td>
                                <td><?php echo e($barang->harga); ?></td>
                                <td><?php echo e($barang->deskripsi); ?></td>
                                <td><?php echo e($barang->satuan->nama); ?></td>
                                <td>
                                    <div class="d-flex">
                                        <a href="<?php echo e(route('barangs.show', ['barang' => $barang->id])); ?>" class="btn btn-outline-dark btn-sm me-2"><i class="bi-person-lines-fill"></i></a>
                                        <a href="<?php echo e(route('barangs.edit', ['barang' => $barang->id])); ?>" class="btn btn-outline-dark btn-sm me-2"><i class="bi-pencil-square"></i></a>

                                        <div>
                                            <form action="<?php echo e(route('barangs.destroy', ['barang' => $barang->id])); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
                                                <button type="submit" class="btn btn-outline-dark btn-sm me-2"><i class="bi-trash"></i></button>
                                            </form>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\ANDHIKA\BELAJAR WEB\LARAVEL\UTS Laravel - Copy\masterBarangUts\resources\views/barang/index.blade.php ENDPATH**/ ?>