@extends('layouts.app')

@section('content')

    {{-- Content awal --}}
        <div class="container mt-4">
            <h4>{{ $pageTitle }}</h4>
            <hr>
            <a href="{{ route('barangs.create') }}" class="btn btn-primary mb-3">Add Barang</a>
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>Nama Barang</th>
                            <th>Deskripsi</th>
                            <th>Jenis barang</th>
                            <th>Stock Barang</th>
                            <th>Harga Beli</th>
                            <th>Harga Jual</th>
                            <th>Gambar barang</th>

                            <!-- <th>Kode</th>
                            <th>Nama Barang</th>
                            <th>Harga</th>
                            <th>Deskripsi</th>
                            <th>Type</th>
                            <th>Action</th> -->
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($barangs as $barang)
                            <tr>
                                <td>{{ $barang->kode }}</td>
                                <td>{{ $barang->nama }}</td>
                                <td>{{ $barang->harga }}</td>
                                <td>{{ $barang->deskripsi }}</td>
                                <td>{{ $barang->satuan->nama }}</td>
                                <td>
                                    <div class="d-flex">
                                        <a href="{{ route('barangs.show', ['barang' => $barang->id]) }}" class="btn btn-outline-dark btn-sm me-2"><i class="bi-person-lines-fill"></i></a>
                                        <a href="{{ route('barangs.edit', ['barang' => $barang->id]) }}" class="btn btn-outline-dark btn-sm me-2"><i class="bi-pencil-square"></i></a>

                                        <div>
                                            <form action="{{ route('barangs.destroy', ['barang' => $barang->id]) }}" method="POST">
                                                @csrf
                                                @method('delete')
                                                <button type="submit" class="btn btn-outline-dark btn-sm me-2"><i class="bi-trash"></i></button>
                                            </form>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    {{-- Content akhir --}}
    
@endsection