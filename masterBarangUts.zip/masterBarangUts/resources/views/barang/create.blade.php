@extends('layouts.app')

@section('content')
    
      {{-- Content awal --}}
  <div class="container-sm mt-5">
    <form action="{{ route('barangs.store') }}" method="POST">
        @csrf
        <div class="row justify-content-center">
            <div class="p-5 bg-light rounded-3 col-xl-6">
                <div class="mb-3 text-center">
                    <i class="bi-person-circle fs-1"></i>
                    <h4>Form Input</h4>
                </div>
                <hr>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="kode" class="form-label">Nama Barang</label>
                        <input class="form-control @error('kode') is-invalid @enderror" type="text" name="kode" id="kode" value="{{ Request::old('kode') }}" placeholder="Enter Nama Barang">
                        @error('kode')
                            <div class="text-danger"><small>{{ $message }}</small></div>
                        @enderror
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="nama" class="form-label">Deskripsi</label>
                        <input class="form-control @error('nama') is-invalid @enderror" type="text" name="nama" id="nama" value="{{ old('nama') }}" placeholder="Enter Nama Deskripsi">
                        @error('nama')
                            <div class="text-danger"><small>{{ $message }}</small></div>
                        @enderror
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="harga" class="form-label">Jenis Barang</label>
                        <input class="form-control @error('harga') is-invalid @enderror" type="text" name="harga" id="harga" value="{{ old('harga') }}" placeholder="Enter Jenis Barang">
                        @error('harga')
                            <div class="text-danger"><small>{{ $message }}</small></div>
                        @enderror
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="deskripsi" class="form-label">Stock Barang</label>
                        <input class="form-control @error('deskripsi') is-invalid @enderror" type="text" name="deskripsi" id="deskripsi" value="{{ old('deskripsi') }}" placeholder="Enter Stock Barang">
                        @error('deskripsi')
                            <div class="text-danger"><small>{{ $message }}</small></div>
                        @enderror
                    </div>
                    <div class="col-md-12 mb-3">
                        <label for="satuan" class="form-label">Harga Beli</label>
                        <input class="form-control @error('hargabeli') is-invalid @enderror" type="text" name="hargabeli" id="hargabeli" value="{{ old('hargabeli') }}" placeholder="Enter Harga Beli">
                        <!-- <select name="satuan" id="satuan" class="form-select"> -->
                            @foreach ($satuans as $satuan)
                                <!-- <option value="{{ $satuan->id }}" {{ old('satuan') == $satuan->id ? 'selected' : '' }}>{{ $satuan->nama }}</option> -->
                            @endforeach
                        </select>
                        @error('satuan')
                            <div class="text-danger"><small>{{ $message }}</small></div>
                        @enderror
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="deskripsi" class="form-label">Harga Jual</label>
                        <input class="form-control @error('deskripsi') is-invalid @enderror" type="text" name="deskripsi" id="deskripsi" value="{{ old('deskripsi') }}" placeholder="Enter Harga Jual">
                        @error('deskripsi')
                            <div class="text-danger"><small>{{ $message }}</small></div>
                        @enderror
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="deskripsi" class="form-label">Gambar barang</label>
                        <input class="form-control @error('deskripsi') is-invalid @enderror" type="image" name="deskripsi" id="deskripsi" value="{{ old('deskripsi') }}" placeholder="Enter deskripsi Barang">
                        @error('deskripsi')
                            <div class="text-danger"><small>{{ $message }}</small></div>
                        @enderror
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-md-6 d-grid">
                        <a href="{{ route('barangs.index') }}" class="btn btn-outline-dark btn-lg mt-3"><i class="bi-arrow-left-circle me-2"></i> Cancel</a>
                    </div>
                    <div class="col-md-6 d-grid">
                        <button type="submit" class="btn btn-outline-dark btn-lg mt-3"><i class="bi-check-circle me-2"></i> Save</button>
                    </div>
                </div>
            </div>
        </div>
    </form>
  </div>
  {{-- Contetnt akhir --}}

@endsection