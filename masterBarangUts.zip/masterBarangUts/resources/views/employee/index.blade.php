@extends('layouts.app')

@section('content')

    {{-- Content awal --}}
        <div class="container mt-4">
            <h4>{{ $pageTitle }}</h4>
            <hr>
            <a href="{{ route('employees.create') }}" class="btn btn-primary mb-3">Add Pembeli</a>
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>Nama</th>
                            <th>TTL</th>
                            <th>Jenis kelamin</th>
                            <th>Alamat</th>
                            <th>Foto KTP</th>
                            <th>Password</th>
                            <th>Retype Password</th>

                            <!-- <th>First Name</th>
                            <th>Last Name</th>
                            <th>Email</th>
                            <th>Age</th>
                            <th>Position</th>
                            <th>Action</th> -->
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($employees as $employee)
                            <tr>
                                <td>{{ $employee->firstname }}</td>
                                <td>{{ $employee->lastname }}</td>
                                <td>{{ $employee->email }}</td>
                                <td>{{ $employee->age }}</td>
                                <td>{{ $employee->position->name }}</td>
                                <td>
                                    <div class="d-flex">
                                        <a href="{{ route('employees.show', ['employee' => $employee->id]) }}" class="btn btn-outline-dark btn-sm me-2"><i class="bi-person-lines-fill"></i></a>
                                        <a href="{{ route('employees.edit', ['employee' => $employee->id]) }}" class="btn btn-outline-dark btn-sm me-2"><i class="bi-pencil-square"></i></a>

                                        <div>
                                            <form action="{{ route('employees.destroy', ['employee' => $employee->id]) }}" method="POST">
                                                @csrf
                                                @method('delete')
                                                <button type="submit" class="btn btn-outline-dark btn-sm me-2"><i class="bi-trash"></i></button>
                                            </form>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    {{-- Content akhir --}}
    
@endsection