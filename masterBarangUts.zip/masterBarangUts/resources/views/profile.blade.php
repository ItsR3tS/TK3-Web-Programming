@extends('layouts.app')

{{-- Content awal --}}
@section('content')
  @include('default_content')
@endsection
{{-- Content akhir --}}