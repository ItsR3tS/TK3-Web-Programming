<?php

namespace App\Http\Controllers;

use App\Models\Staff;
use App\Models\Position;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class StaffController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $pageTitle = 'Staff List';

        // // Query Builder
        // $staffs = DB::table('staffs')
        //     ->select('*', 'staffs.id as employee_id')
        //     ->leftJoin('positions', 'staffs.position_id', 'positions.id')
        //     ->get();

        // ELOQUENT
        $staffs = Staff::all();

        return view('staff/index', [
            'pageTitle' => $pageTitle,
            'staffs' => $staffs
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $pageTitle = 'Create staff';
        // $positions = DB::table('positions')->get();

        // ELOQUENT
        $positions = Position::all();

        return view('staff/create', [
            'pageTitle' => $pageTitle,
            'positions' => $positions
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'firstName' => 'required',
            'email' => 'required|email|unique:staffs,email',
            'age' => 'required|numeric',
            'position' => 'required'
        ]);

        // INSERT QUERY
        // DB::table('staffs')->insert([
        //     'firstname' => $request->firstName,
        //     'lastname' => $request->lastName,
        //     'email' => $request->email,
        //     'age' => $request->age,
        //     'position_id' => $request->position
        // ]);

        // ELOQUENT
        $staff = new Staff;
        $staff->firstname = $request->firstName;
        $staff->lastname = $request->lastName;
        $staff->email = $request->email;
        $staff->age = $request->age;
        $staff->position_id = $request->position;
        $staff->save();

        
        return redirect()->route('staffs.index'); 
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $pageTitle = 'Staff Detail';
        // $staff = DB::table('staffs')
        //     ->select('*', 'staffs.id as employee_id', 'positions.name as position_name')
        //     ->leftJoin('positions', 'staffs.position_id', 'positions.id')
        //     ->where('staffs.id', $id)
        //     ->first();

        // ELOQUENT
        $staff = Staff::find($id);

        return view('staff.show', [
            'pageTitle' => $pageTitle, 
            'staff' => $staff
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $pageTitle = 'Edit Staff';
        // $positions = DB::table('positions')->get();
        // $staff = DB::table('staffs')
        //     ->select('*', 'staffs.id as employee_id', 'positions.id as position_id')
        //     ->leftJoin('positions', 'staffs.position_id', 'positions.id')
        //     ->where('staffs.id', $id)
        //     ->first();

        // ELOQUENT
        $positions = Position::all();
        $staff = Staff::find($id);

        return view('staff.edit', [
            'pageTitle' => $pageTitle, 
            'positions' => $positions, 
            'staff' => $staff
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'firstName' => 'required',
            'email' => 'required|email|unique:staffs,email,'.$id,
            'age' => 'required|numeric',
            'position' => 'required'
        ]);

        // UPDATE QUERY
        // DB::table('staffs')
        //     ->where('id', $id)
        //     ->update([
        //         'firstname' => $request->firstName,
        //         'lastname' => $request->lastName,
        //         'email' => $request->email,
        //         'age' => $request->age,
        //         'position_id' => $request->position,
        //     ]);

        // ELOQUENT
        $staff = Staff::find($id);
        $staff->firstname = $request->firstName;
        $staff->lastname = $request->lastName;
        $staff->email = $request->email;
        $staff->age = $request->age;
        $staff->position_id = $request->position;
        $staff->save();

        return redirect()->route('staffs.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        // DELETE QUERY
        // DB::table('staffs')
        //     ->where('id', $id)
        //     ->delete();

        // ELOQUENT
        $staff = Staff::find($id);
        $staff -> delete(); 

        return redirect()->route('staffs.index');
    }
}
